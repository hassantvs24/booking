<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> | Booking</title>

    <!-- Global stylesheets -->
    <link href="<?php echo e(asset('public/fonts.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/core.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Global stylesheets -->
<!--Phone Number-->
    <link href="<?php echo e(asset('public/assets/dial_code_flag/css/intlTelInput.css')); ?>" rel="stylesheet" type="text/css">
<!--Phone Number-->
    <link href="<?php echo e(asset('public/assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->
    <link href="<?php echo e(asset('public/custom.css')); ?>" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="navbar-top <?php echo e(Session::get('sidebarState')); ?>">
<!-- Main navbar -->
    <?php echo $__env->make('shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /Main navbar -->

<!-- Page container -->
<div class="page-container">
    <!-- Page content -->
    <div class="page-content">
        <!-- Main sidebar -->
            <?php echo $__env->make('shared.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /Main sidebar -->

        <!-- Main content -->
        <div class="content-wrapper" style="min-height: 100vh;">

            <!-- Content area -->
            <div class="content" style="min-height: 100vh; position: relative;">

                <?php echo $__env->yieldContent('content'); ?>

                <!-- Basic modal -->
                <?php echo $__env->yieldContent('box'); ?>
                <!-- /basic modal -->

                <!-- Footer -->
                <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /footer -->
            </div>
            <!-- /Content area -->

        </div>
        <!-- /Main content -->
    </div>
    <!-- /Page content -->
</div>
<!-- /Page container -->


<!-- Core JS files -->
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/loaders/pace.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/core/libraries/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/core/libraries/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
<!-- /core JS files -->

<!-- For Fixed Layout JS files -->
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/ui/nicescroll.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/datetime-moment.js')); ?>"></script><!--Datatable Date Sorting Plugin-->
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/notifications/jgrowl.min.js')); ?>"></script>

<!--Phone Number-->
<script type="text/javascript" src="<?php echo e(asset('public/assets/dial_code_flag/js/intlTelInput.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/dial_code_flag/js/defaultCountryIp.js')); ?>"></script>
<!--Phone Number-->
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/core/app.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/pages/layout_fixed_custom.js')); ?>"></script>
<!-- /For Fixed Layout JS files -->


<script type="text/javascript" src="<?php echo e(asset('public/custom.js')); ?>"></script>

<?php if(session()->has('save')): ?>
    <script type="text/javascript">
        $(function () {
            $.jGrowl("<?php echo e(__('site.notify.save')); ?>", {
                header: 'Success',
                theme: 'bg-success',
                life: 1500,
                position: 'top-center'
            });
        });
    </script>
<?php endif; ?>

<?php if(session()->has('edit')): ?>
    <script type="text/javascript">
        $(function () {
            $.jGrowl("<?php echo e(__('site.notify.edit')); ?>", {
                header: 'Success',
                theme: 'bg-success',
                life: 1500,
                position: 'top-center'
            });
        });
    </script>
<?php endif; ?>

<?php if(session()->has('del')): ?>
    <script type="text/javascript">
        $(function () {
            $.jGrowl("<?php echo e(__('site.notify.del')); ?>", {
                header: 'Success',
                theme: 'bg-success',
                life: 1500,
                position: 'top-center'
            });
        });
    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script type="text/javascript">
        $(function () {
            $.jGrowl("<?php echo e(__('site.notify.error')); ?>", {
                header: 'Error',
                theme: 'bg-danger',
                life: 1500,
                position: 'top-center'
            });
        });
    </script>
<?php endif; ?>

<script type="text/javascript">



    $(function () {
        $.fn.dataTable.moment( 'DD/MM/YYYY');<!--Datatable Date Sorting Plugin-->

        $.extend(
            $.fn.dataTable.defaults, {
            autoWidth: false,
            pageLength: 25,// row show
            dom: '<"datatable-header"fl><"datatable-scroll"t><"datatable-footer"ip>',
            language: {
                search: '<span>Filter:</span> _INPUT_',
                lengthMenu: '<span>Show:</span> _MENU_',
            },
            drawCallback: function () {
                $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
            },
            preDrawCallback: function() {
                $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
            }
        });



    <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type')); ?>";
        switch(type){
            case 'info':
                $.jGrowl("<?php echo e(Session::get('message')); ?>", {
                    header: 'Info',
                    theme: 'bg-info',
                    life: 800,
                    position: 'top-center'
                });
                break;

            case 'warning':
                $.jGrowl("<?php echo e(Session::get('message')); ?>", {
                    header: 'Warning',
                    theme: 'bg-warning',
                    life: 800,
                    position: 'top-center'
                });
                break;

            case 'success':
                $.jGrowl("<?php echo e(Session::get('message')); ?>", {
                    header: 'Success',
                    theme: 'bg-success',
                    life: 800,
                    position: 'top-center'
                });
                break;

            case 'error':
                $.jGrowl("<?php echo e(Session::get('message')); ?>", {
                    header: 'Error',
                    theme: 'bg-danger',
                    life: 800,
                    position: 'top-center'
                });
                break;
        }
        <?php endif; ?>

    });


    function imgPrev(input, outPut) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $(outPut).attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }



</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<!--
Copyright © Infinity Flame Soft
Author: Nazmul Hossain
Company: Infinity Flame Soft
Contact: +8801675870047
Email: wall.mate@gmail.com
--><?php /**PATH C:\wamp64\www\booking\resources\views\layouts\master.blade.php ENDPATH**/ ?>