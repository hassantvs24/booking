<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.user_permission_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-6">
            <p><a href="<?php echo e(route('user-role')); ?>" class="btn btn-danger btn-labeled"><b><i class="icon-previous2"></i></b> <?php echo app('translator')->get('site.content.user_role_go'); ?></a></p>
        </div>
        <div class="col-md-6">

            <?php if($errors->any()): ?>
                <div class="notification is-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.user_permission_page'); ?> for <b class="text-danger"><?php echo e($table->name); ?></b></h6>
                </div>
                <form action="<?php echo e(route('user-permission-update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="userRuleID" value="<?php echo e($table->id); ?>">
                <div class="panel-body">
                    <div class="row">
                        <?php
                            $permission_list = collect($permissions)->chunk(10);
                            $permission_list->toArray();

                        //dd($permission_list);
                        ?>

                        <?php $__currentLoopData = $permission_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contains): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">

                                <?php $__currentLoopData = $contains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="access[]" class="styled" value="<?php echo e($row['access']); ?>" <?php echo e($table->check($row['access']) ? 'checked' : ''); ?>>
                                            <?php echo e($row['name']); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <div class="panel-footer">
                    <div class="heading-elements">
                        <button type="submit" id="pes" class="btn btn-primary heading-btn pull-right"><i class="icon-checkmark4"></i> Save changes</button>
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/forms/styling/switchery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/forms/styling/switch.min.js')); ?>"></script>



    <script type="text/javascript">




    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\users\action\permission.blade.php ENDPATH**/ ?>