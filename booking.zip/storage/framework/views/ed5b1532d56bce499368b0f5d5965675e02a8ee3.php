<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.service_edi'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <p><a href="<?php echo e(route('service')); ?>" class="btn btn-danger btn-labeled"><b><i class="icon-previous2"></i></b> <?php echo app('translator')->get('site.content.go_service'); ?></a></p>
        </div>
        <div class="col-md-6">
            <?php if($errors->any()): ?>
                <div class="notification is-danger">
                    <button class="delete bt-del"></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.service_edi'); ?></h6>
                </div>
                <form id="serviceForm" action="<?php echo e(route('service-edit', ['id' => $table->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="panel-body mainFrom">

                        <div class="row">
                            <div class="col-md-6">
                                <fieldset>
                                    <legend class="text-semibold"><i class="icon-reading position-left"></i> Basic details</legend>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Service Type</span>
                                        <select type="text" id="venueBooking" name="serviceType" class="form-control">
                                            <option value="Venue Booking">Venue Booking</option>
                                            <option value="Food & Catering">Food & Catering</option>
                                            <option value="Photographer">Photographer</option>
                                            <option value="Henna Artist">Henna Artist</option>
                                            <option value="Makeup Artist">Makeup Artist</option>
                                            <option value="Event Planer">Event Planer</option>
                                            <option value="Invitation Card">Invitation Card</option>
                                        </select>
                                    </div>

                                    <?php if(Auth::user()->userType == 'Vendor'): ?>
                                        <input type="hidden" name="vendorID" value="<?php echo e(Auth::user()->id); ?>">
                                    <?php else: ?>
                                        <div class="input-group mb-5">
                                            <span class="input-group-addon">Vendor*</span>
                                            <select id="vendorID" type="text" name="vendorID" class="form-control select" required>
                                                <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?> (<?php echo e($row->contact); ?>)</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Name*</span>
                                        <input type="text" name="name" class="form-control" value="<?php echo e($table->name); ?>" placeholder="Service Name/Company" required />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Email</span>
                                        <input type="email" name="email" class="form-control" value="<?php echo e($table->email); ?>" placeholder="Email" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Location*</span>
                                        <select id="locationSet" type="text" name="locationID" class="form-control">
                                            <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Address</span>
                                        <input type="text" name="address" class="form-control" value="<?php echo e($table->address); ?>" placeholder="Address" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Landmark</span>
                                        <input type="text" name="landmark" class="form-control" value="<?php echo e($table->landmark); ?>" placeholder="Landmark" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Min Guest*</span>
                                        <input type="number" name="minGuest" class="form-control" min="0" value="<?php echo e($table->minGuest); ?>" placeholder="Min Guest" required />
                                        <span class="input-group-addon">Max Guest*</span>
                                        <input type="number" name="maxGuest" class="form-control" min="0" value="<?php echo e($table->maxGuest); ?>" placeholder="Max Guest" required />
                                    </div>

                                    <?php
                                        $contact = json_decode($table->contact, true);

                                        $additional = json_decode($table->additional, true);
                                        $partyType_json = $additional['partyType'];
                                        $faq_json = $additional['faq'];

                                        //dd($partyType_json);


                                       $facility_json = json_decode($table->facility, true);
                                       $rules_json = json_decode($table->rules, true);


                                        $facil = "";
                                        foreach ($facility_json as $val){
                                            $facil .= str_replace('"', '',$val).',';
                                        }
                                        $facilitys = rtrim($facil, ',');

                                        $ru = "";
                                        foreach ($rules_json as $val){
                                            $ru .= str_replace('"', '',$val).',';
                                        }
                                        $ruleses = rtrim($ru, ',');

                                        $partyType = "";
                                        if($partyType_json != null){
                                            $party = "";
                                            foreach ($partyType_json as $val){
                                                $party .= str_replace('"', '',$val).',';
                                            }
                                            $partyType = rtrim($party, ',');
                                        }





                                        $social = json_decode($table->social, true);
                                        $pricing = json_decode($table->pricing, true);
                                        $photos = json_decode($table->photos, true);

                                    ?>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Mobile*</span>
                                        <input type="text" name="mobile" class="form-control" value="<?php echo e($contact['mobile'] ?? 0); ?>" placeholder="11 Digit Mobile Number" required />
                                        <span class="input-group-addon">Land Phone</span>
                                        <input type="text" name="phone" class="form-control" value="<?php echo e($contact['phone'] ?? 0); ?>" placeholder="Phone Number" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">WhatsApp</span>
                                        <input type="text" name="WhatsApp" class="form-control" value="<?php echo e($contact['whatsApp'] ?? 0); ?>" placeholder="WhatsApp" />
                                        <span class="input-group-addon">Viber</span>
                                        <input type="text" name="Viber" class="form-control" value="<?php echo e($contact['viber'] ?? 0); ?>" placeholder="Viber" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Website Link</span>
                                        <input type="text" name="website" class="form-control" value="<?php echo e($table->website); ?>" placeholder="Website Link" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Short Description</span>
                                        <input type="text" name="additional" class="form-control" placeholder="Max 255 letter Short Description [Optional]" value="<?php echo e($additional['description'] ?? ''); ?>" />
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Profile Photo*</span>
                                        <input type="file" name="primaryPhoto" class="form-control" placeholder="Profile Photo" accept="image/x-png,image/gif,image/jpeg"/>
                                    </div>

                                </fieldset>
                            </div>

                            <div class="col-md-6">
                                <fieldset>
                                    <legend class="text-semibold"><i class="icon-truck position-left"></i> Other details</legend>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Party Type</span>
                                        <select  id="partyTypes"class="form-control select" name="partyType[]" multiple="multiple">
                                            <?php $__currentLoopData = $partyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Facility</span>
                                        <select id="facility" class="form-control select" name="facility[]" multiple="multiple">
                                            <?php $__currentLoopData = $facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="input-group mb-5">
                                        <span class="input-group-addon">Rules</span>
                                        <select id="rules" class="form-control select" name="rules[]" multiple="multiple">
                                            <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="mb-5"><button id="addSocial" type="button" class="btn btn-link"><i class="icon-plus2"></i> Add Social Link</button></div>
                                    <div id="socialShow">
                                        <?php $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="input-group mb-5 gnInput">
                                                <span class="input-group-addon">Name</span>
                                                <input type="text" name="socialName[]" class="form-control" value="<?php echo e($row['name'] ?? ''); ?>" placeholder="Ex: Facebook" required/>
                                                <span class="input-group-addon">Link</span>
                                                <input type="url" name="socialLink[]" class="form-control" value="<?php echo e($row['link'] ?? ''); ?>"  placeholder="Social Link" required/>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-danger delInput" type="button">X</button>
                                                </span>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>


                                    <div class="mb-5"><button id="addPackage" type="button" class="btn btn-link"><i class="icon-plus2"></i> Add Package and pricing setup</button></div>
                                    <div id="packageShow">
                                        <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="input-group mb-5 gnInput">
                                                <span class="input-group-addon">Package Name</span>
                                                <input type="text" name="package[]" class="form-control" value="<?php echo e($row['name'] ?? ''); ?>" placeholder="Package Name" required/>
                                                <span class="input-group-addon">Item</span>
                                                <input type="text" name="items[]" class="form-control" value="<?php echo e($row['item'] ?? ''); ?>" placeholder="Package Item" required/>
                                                <span class="input-group-addon">Price</span>
                                                <input type="number" name="price[]" class="form-control" min="0" value="<?php echo e($row['price'] ?? 0); ?>" placeholder="Package Price" required/>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-danger delInput" type="button">X</button>
                                                </span>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="mb-5"><button id="addFaq" type="button" class="btn btn-link"><i class="icon-plus2"></i> Add FAQ</button></div>
                                    <div id="faqShow">
                                        <?php $__currentLoopData = $faq_json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="input-group mb-5 gnInput">
                                                <span class="input-group-addon">Question</span>
                                                <input type="text" name="question[]" class="form-control" value="<?php echo e($row['question'] ?? ''); ?>" placeholder="FAQ Question" required/>
                                                <span class="input-group-addon">Answer</span>
                                                <input type="text" name="answer[]" class="form-control" value="<?php echo e($row['answer'] ?? ''); ?>" placeholder="Answer This" required/>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-danger delInput" type="button">X</button>
                                                </span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="mb-5"><button id="addPhoto" type="button" class="btn btn-link"><i class="icon-plus2"></i> Add Photo Gallery</button></div>
                                    <div id="photoShow"></div>

                                </fieldset>
                            </div>
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo e(asset('public/gallery/'.$row['photo'])); ?>" alt="<?php echo e($row['name']); ?>">
                                            <div class="caption-overflow">
                                            <span>
                                                <?php if($i != 0): ?>
                                                <a href="<?php echo e(route('service-del-photo', ['id' => $table->id, 'key' => $i])); ?>" class="btn border-white text-white btn-flat btn-icon btn-rounded ml-5" onclick='return confirm("<?php echo e(__('site.common.delete')); ?>")' title="<?php echo e(__('site.common.del_title')); ?>"><i class="icon-trash"></i></a>
                                                    <?php endif; ?>
                                            </span>
                                            </div>
                                        </div>

                                        <div class="caption">
                                            <h6 class="no-margin"><a href="#" class="<?php echo e($i == 0 ? 'text-blue':'text-default'); ?>"><?php echo e($row['name']); ?></a></h6>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <textarea id="content" name="description" rows="3" style="width: 100%;" class="hidden"></textarea>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="summernote"><?php echo urldecode($table->description) ?? ''; ?></div>
                            </div>
                        </div>

                    </div>

                    <div class="panel-footer">
                        <div class="heading-elements">
                            <button id="go_submit" style="display: none;" type="submit"></button>
                            <button type="button" id="pes" class="btn btn-primary heading-btn pull-right"><i class="icon-checkmark4"></i> Save changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('public/assets/css/icons/fontawesome/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/summernote/summernote.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- Theme JS files -->
    <script type="text/javascript" src="<?php echo e(asset('public/summernote/summernote.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>

    <!-- /theme JS files -->



    <script type="text/javascript">

        $(function () {

            $('.delInput').click(function () {
                $(this).parents('.gnInput').remove();
            });

            $('#addSocial').click(function () {

                $('#socialShow').append('<div class="input-group mb-5 gnInput">\n' +
                    '<span class="input-group-addon">Name</span>\n' +
                    '<input type="text" name="socialName[]" class="form-control" placeholder="Ex: Facebook" required/>\n' +
                    '<span class="input-group-addon">Link</span>\n' +
                    '<input type="url" name="socialLink[]" class="form-control" placeholder="Social Link" required/>\n' +
                    '<span class="input-group-btn">\n' +
                    '<button class="btn btn-danger delInput" type="button">X</button>\n' +
                    '</span>\n' +
                    '</div>');

                $('.delInput').click(function () {
                    $(this).parents('.gnInput').remove();
                });
            });



            $('#addPackage').click(function () {

                $('#packageShow').append('<div class="input-group mb-5 gnInput">\n' +
                    ' <span class="input-group-addon">Package Name</span>\n' +
                    ' <input type="text" name="package[]" class="form-control" placeholder="Package Name" required/>\n' +
                    ' <span class="input-group-addon">Item</span>\n' +
                    ' <input type="text" name="items[]" class="form-control" placeholder="Package Item" required/>\n' +
                    ' <span class="input-group-addon">Price</span>\n' +
                    ' <input type="number" name="price[]" class="form-control" min="0" value="0" placeholder="Package Price" required/>\n' +
                    ' <span class="input-group-btn">\n' +
                    '   <button class="btn btn-danger delInput" type="button">X</button>\n' +
                    '  </span>\n' +
                    '</div>');

                $('.delInput').click(function () {
                    $(this).parents('.gnInput').remove();
                });
            });


            $('#addFaq').click(function () {

                $('#faqShow').append('<div class="input-group mb-5 gnInput">\n' +
                    ' <span class="input-group-addon">Question</span>\n' +
                    ' <input type="text" name="question[]" class="form-control" placeholder="FAQ Question" required/>\n' +
                    ' <span class="input-group-addon">Answer</span>\n' +
                    ' <input type="text" name="answer[]" class="form-control" placeholder="Answer This" required/>\n' +
                    ' <span class="input-group-btn">\n' +
                    '   <button class="btn btn-danger delInput" type="button">X</button>\n' +
                    '  </span>\n' +
                    '</div>');

                $('.delInput').click(function () {
                    $(this).parents('.gnInput').remove();
                });
            });


            $('#addPhoto').click(function () {

                $('#photoShow').append('<div class="input-group mb-5 gnInput">\n' +
                    '<span class="input-group-addon">Photo Caption</span>\n' +
                    '<input type="text" name="photoName[]" class="form-control" placeholder="Photo Caption" required/>\n' +
                    '<span class="input-group-addon">Upload Photo</span>\n' +
                    '<input type="file" name="gallery[]" class="form-control" placeholder="Upload Gallery Photo" accept="image/x-png,image/gif,image/jpeg" required/>\n' +
                    '  <span class="input-group-btn">\n' +
                    '     <button class="btn btn-danger delInput" type="button">X</button>\n' +
                    '  </span>\n' +
                    '</div>');

                $('.delInput').click(function () {
                    $(this).parents('.gnInput').remove();
                });
            });



            $('.summernote').summernote({
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline', 'clear']],
                    ['fontname', ['fontname']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    ['table', ['table']],
                    ['insert', ['link', 'hr']],
                    ['view', ['fullscreen']],
                    ['help', ['help']]
                ]
            });

            //$('.select').select2();

            $('#pes').click(function () {
                var content = $('.summernote').summernote('code');

                $('#content').val(encodeURIComponent(content));

                $('#go_submit').trigger('click');

                //$('#serviceForm').submit();
            });
        });


        $(function () {

            $('#locationSet').val("<?php echo e($table->locationID); ?>");
            $('#venueBooking').val("<?php echo e($table->serviceType); ?>");

            $('#facility').val([<?php echo e($facilitys); ?>]);
            $('#facility').select2();

            $('#rules').val([<?php echo e($ruleses); ?>]);
            $('#rules').select2();

            $('#partyTypes').val([<?php echo e($partyType); ?>]);
            $('#partyTypes').select2();

            $('#vendorID').val(<?php echo e($table->vendorID); ?>);
            $('#vendorID').select2();

        });



    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\service\action\edit.blade.php ENDPATH**/ ?>