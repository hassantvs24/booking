<?php $__env->startSection('title'); ?>
    Customer Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- breadcrumb-section - start
		================================================== -->
    <section id="breadcrumb-section" class="breadcrumb-section clearfix">
        <div class="jarallax" style="background-image: url(<?php echo e(asset('public/frontend/assets/images/breadcrumb/0.breadcrumb-bg.jpg')); ?>);">
            <div class="overlay-black">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">

                            <!-- breadcrumb-title - start -->
                            <div class="breadcrumb-title text-center mb-50">
                                <span class="sub-title">customer profile</span>
                                <h2 class="big-title">Hi <strong>
                                        <?php if(Auth::check()): ?>
                                            <?php echo e(Auth::user()->name); ?>

                                            <?php else: ?>
                                            Customer
                                        <?php endif; ?>
                                    </strong></h2>
                            </div>
                            <!-- breadcrumb-title - end -->

                            <!-- breadcrumb-list - start -->
                            <div class="breadcrumb-list">
                                <ul>
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>" class="breadcrumb-link">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Customer Profile</li>
                                </ul>
                            </div>
                            <!-- breadcrumb-list - end -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-section - end
    ================================================== -->


    <!-- absolute-eventmake-section - start
    ================================================== -->
    <section class="event-search-tab">
        <div id="absolute-eventmake-section" class="absolute-eventmake-section sec-ptb-170 bg-gray-light clearfix">
            <div class="eventmaking-wrapper">
                <ul class="nav eventmake-tabs">

                    <li>
                        <a class="active" data-toggle="tab" href="#ordersummary">
                            order summary
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#transactions">
                            transaction history
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#profile">
                            profile
                        </a>
                    </li>
                </ul>

                <div class="tab-content">

                    <div id="ordersummary" class="tab-pane fade in active show">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th>Date</th>
                                    <th>Service</th>
                                    <th>Company</th>
                                    <th>Package</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $package_json = json_decode($row->package, true);
                                    ?>
                                    <tr>
                                        <td><?php echo e($row->bookingID); ?></td>
                                        <td>
                                            <p style="margin: 0px;"><?php echo e(pub_date($row->created_at)); ?></p>
                                            <small><?php echo e($row->time_slot['name'] ?? ''); ?> (<?php echo e(date('ha', strtotime($row->time_slot['fromTime']))); ?>-<?php echo e(date('ha', strtotime($row->time_slot['toTime']))); ?>)</small>
                                        </td>
                                        <td><?php echo e($row->service['serviceType'] ?? ''); ?></td>
                                        <td><?php echo e($row->service['name'] ?? ''); ?></td>
                                        <td><b class="m-0"><?php echo e($package_json['name'] ?? ''); ?></b> <small class="text-grey-300">(<?php echo e($package_json['item']); ?>)</small></td>
                                        <td>
                                            <p style="margin: 0px;"><?php echo e(money_c($row->pricing * $row->qty)); ?></p>
                                            <small><?php echo e(money_c($row->pricing)); ?> x <?php echo e($row->qty); ?></small>
                                        </td>
                                        <td>

                                            <?php echo e($row->booking['status'] ?? ''); ?>

                                            <?php if($row->booking['status'] == 'Complete'): ?>
                                                <?php
                                                    $review = $row->review();
                                                ?>
                                                <?php if($review == null): ?>
                                                    <a href="#login-modal" data-booking="<?php echo e($row->bookingID); ?>"  data-service="<?php echo e($row->serviceID); ?>" type="button" class="login-modal-btn">Review</a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div id="transactions" class="tab-pane fade">
                        <h3>Current Balance: <b><?php echo e(money_c(Auth::user()->balance)); ?></b></h3>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Booking ID</th>
                                    <th>Payment Method</th>
                                    <th>Description</th>
                                    <th>IN</th>
                                    <th>OUT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $balance = 0;
                                ?>
                                <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(pub_date($row->created_at)); ?></td>
                                    <td><?php echo e($row->refID); ?></td>
                                    <td><?php echo e($row->payMethod); ?></td>
                                    <?php if($row->payType == 'IN'): ?>
                                        <td>Purchase Payment</td>
                                        <?php else: ?>
                                        <td>Payment Return</td>
                                    <?php endif; ?>

                                    <td><?php echo e(money_c($row->amountOUT)); ?></td>
                                    <td><?php echo e(money_c($row->amountIN)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="profile" class="tab-pane fade">
                        <table class="table table-bordered" style="width:500px;">
                            <tbody><tr>
                                <th>User Name</th>
                                <td><?php echo e(Auth::user()->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e(Auth::user()->email); ?></td>
                            </tr>
                            <tr>
                                <th>Mobile Number</th>
                                <td><?php echo e(Auth::user()->contact); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>

    </section>
    <!-- absolute-eventmake-section - end
    ================================================== -->

    <?php echo $__env->make('shared.frontend.review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

        $('.login-modal-btn').click(function () {
            var serviceID = $(this).data('service');
            var bookingID = $(this).data('booking');

            $('#reviewForm [name=serviceID]').val(serviceID);
            $('#reviewForm [name=bookingID]').val(bookingID);

        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views/frontend/user-profile.blade.php ENDPATH**/ ?>