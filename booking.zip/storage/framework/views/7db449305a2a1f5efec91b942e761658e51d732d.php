<div class="header-altranative">
    <div class="container">
        <div class="logo-area float-left">
            <a href="<?php echo e(route('front.home')); ?>">
                <img src="<?php echo e(asset('public/frontend/assets/images/1.site-logo.png')); ?>" alt="logo_not_found">
            </a>
        </div>

        <button type="button" id="sidebarCollapse" class="alt-menu-btn float-right">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- sidebar menu - start -->
    <div class="sidebar-menu-wrapper">
        <div id="sidebar" class="sidebar">
					<span id="sidebar-dismiss" class="sidebar-dismiss">
						<i class="fas fa-arrow-left"></i>
					</span>

            <div class="sidebar-header">
                <a href="<?php echo e(route('front.home')); ?>">
                    <img src="<?php echo e(asset('public/frontend/assets/images/2.site-logo.png')); ?>" alt="logo_not_found">
                </a>
            </div>

            <!-- sidebar-form - start -->
            <div class="sidebar-form">
                <form action="#">
                    <input id="altmenu-sidebar-search" type="search" placeholder="Search">
                    <label for="altmenu-sidebar-search"><i class="fas fa-search"></i></label>
                </form>
            </div>
            <!-- sidebar-form - end -->

            <!-- main-pages-links - start -->
            <div class="menu-link-list main-pages-links">
                <ul>
                    <li>
                        <a href="<?php echo e(route('front.home')); ?>">home</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.about')); ?>">about</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.service')); ?>">services</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.gallery')); ?>">gallery</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.contact')); ?>">contact</a>
                    </li>
                </ul>
            </div>
            <!-- main-pages-links - end -->

            <!-- login-btn-group - start -->
            <div class="login-btn-group">
                <ul>
                    <li>
                        <?php if(Auth::check()): ?>
                            <a href="<?php echo e(route('front.user')); ?>" class="">
                                <i class="fas fa-user"></i>
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('front.login-register')); ?>" class="">
                                <i class="fas fa-bookmark"></i>
                                Register
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if(Auth::check()): ?>
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                <i class="fas fa-lock"></i>
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('front.login-register')); ?>" class="">
                                <i class="fas fa-unlock"></i>
                                Login
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <!-- login-btn-group - end -->

            <!-- social-links - start -->
            <div class="social-links">
                <h2 class="menu-title">get in touch</h2>
                <div class="mb-15">
                    <h3 class="contact-info">
                        <i class="fas fa-phone"></i>
                        01675-870047
                    </h3>
                    <h3 class="contact-info">
                        <i class="fas fa-envelope"></i>
                        info@harmoni.com
                    </h3>
                </div>
                <ul>
                    <li>
                        <a href="#!"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li>
                        <a href="#!"><i class="fab fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#!"><i class="fab fa-twitch"></i></a>
                    </li>
                    <li>
                        <a href="#!"><i class="fab fa-google-plus-g"></i></a>
                    </li>
                    <li>
                        <a href="#!"><i class="fab fa-instagram"></i></a>
                    </li>
                </ul>
                <a href="<?php echo e(route('front.contact')); ?>" class="contact-btn">contact us</a>
            </div>
            <!-- social-links - end -->

            <div class="overlay"></div>
        </div>
    </div>
    <!-- sidebar menu - end -->
</div><?php /**PATH C:\wamp64\www\booking\resources\views\shared\frontend\header-mobile.blade.php ENDPATH**/ ?>