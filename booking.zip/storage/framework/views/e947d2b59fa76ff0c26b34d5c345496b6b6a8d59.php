<?php $__env->startSection('title'); ?>
    Service
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb-section - start
		================================================== -->
    <section id="breadcrumb-section" class="breadcrumb-section clearfix">
        <div class="jarallax" style="background-image: url(<?php echo e(asset('public/frontend/assets/images/breadcrumb/0.breadcrumb-bg.jpg')); ?>);">
            <div class="overlay-black">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">

                            <!-- breadcrumb-title - start -->
                            <div class="breadcrumb-title text-center mb-50">
                                <span class="sub-title">service single</span>
                                <h2 class="big-title">harmoni <strong>service details</strong></h2>
                            </div>
                            <!-- breadcrumb-title - end -->

                            <!-- breadcrumb-list - start -->
                            <div class="breadcrumb-list">
                                <ul>
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>" class="breadcrumb-link">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($table->name); ?> Details</li>
                                </ul>
                            </div>
                            <!-- breadcrumb-list - end -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-section - end
    ================================================== -->


    <?php


        $social = json_decode($table->social, true);
        $pricing = json_decode($table->pricing, true);
        $photos = json_decode($table->photos, true);
        $facility = json_decode($table->facility, true);
        $rules = json_decode($table->rules, true);
        $contact = json_decode($table->contact, true);
        $additional = json_decode($table->additional, true);
        $faq_json = $additional['faq'];

    ?>



    <!-- event-details-section - start
    ================================================== -->
    <section id="event-details-section" class="event-details-section sec-ptb-100 clearfix">
        <div class="container">
            <div class="row">

                <!-- col - event-details - start -->
                <div class="col-lg-8 col-md-12 col-sm-12">

                    <!-- event-details - start -->
                    <div class="event-details mb-80">

                        <div class="event-title mb-30">
                            <h2 class="event-title"><?php echo e($table->name); ?></h2>
                        </div>

                        <div id="event-details-carousel" class="event-details-carousel owl-carousel owl-theme">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($i != 0): ?>
                            <div class="item">
                                <img src="<?php echo e(asset('public/gallery/'.$row['photo'])); ?>" alt="Image_not_found">
                            </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <!-- event-details - end -->

                    <!-- event-schedule - start -->
                    <div class="event-schedule">

                        <!-- schedule-wrapper - start -->
                        <div class="schedule-wrapper">

                            <div class="tab-content">

                                <div id="day1" class="tab-pane fade in active show">
                                    <?php echo urldecode($table->description) ?? ''; ?>

                                </div>

                            </div>
                        </div>
                        <!-- schedule-wrapper - end -->

                    </div>
                    <!-- event-schedule - end -->

                    <br><br>

                    <div class="reviewer-comment-wrapper mb-30 clearfix">
                        <?php
                            $comment = $table->review()->orderBy('id', 'DESC')->get();
                        ?>

                        <div class="section-title text-left mb-50">
                            <h2 class="big-title">Event <strong>reviews</strong></h2>
                            <small>Rating: <b><?php echo e($table->rating); ?>/5</b> (<?php echo e($comment->count()); ?>)</small>
                        </div>

                        <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="comment-bar clearfix">
                                <div class="admin-image">
                                    <img src="<?php echo e(asset('public/frontend/assets/images/user_img.png')); ?>" alt="Image_not_found">
                                </div>
                                <div class="comment-content">
                                    <div class="admin-name mb-15">
                                        <div class="rateing-star ul-li clearfix" title="<?php echo e($row->rating ?? 0); ?>">
                                            <ul>
                                                <?php for($i = 0; $i<floor($row->rating); $i++): ?>
                                                    <li class="rated"><i class="fas fa-star"></i></li>
                                                <?php endfor; ?>
                                            </ul> &nbsp;|&nbsp;
                                            <small><?php echo e(pub_date($row->created_at)); ?></small>
                                        </div>
                                        <div class="name">
                                            <a href="#!"><?php echo e($row->user['name'] ?? 'Unnamed'); ?></a>
                                        </div>
                                    </div>
                                    <div class="comment-text">
                                        <p class="mb-30">
                                            <?php echo e($row->comment ?? ''); ?>

                                        </p>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>



                </div>
                <!-- col - event-details - end -->

                <!-- sidebar-section - start -->
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="sidebar-section">

                        <!-- map-wrapper - start -->
                        <div class="map-wrapper mb-30">

                            <!-- section-title - start -->
                            <div class="section-title mb-30">
                                <h2 class="big-title">Service <strong>location</strong></h2>
                            </div>
                            <!-- section-title - end -->

                            <div style="position: relative;">
                                <fieldset class="gllpLatlonPicker"  style="width: 100%;">
                                    <input type="hidden" name="lat" class="gllpLatitude" value="<?php echo e($table->lat ?? '23.78'); ?>"/>
                                    <input type="hidden" name="lon" class="gllpLongitude" value="<?php echo e($table->lon ?? '90.40'); ?>"/>
                                    <div class="gllpMap" style="width: 100%;">Google Maps</div>
                                    <input type="hidden" class="gllpLatLng"/>
                                    <input type="hidden" class="gllpZoom" value="15"/>
                                </fieldset>
                            </div>

                        </div>
                        <!-- map-wrapper - end -->

                        <!-- location-wrapper - start -->
                        <div class="location-wrapper mb-30">
                            <div class="title-wrapper">
                                <span class="icon">
										<i class="fas fa-map-marker-alt"></i>
									</span>
                                <div class="title-content">
                                    <small><?php echo e($table->address); ?></small>
                                </div>
                            </div>

                            <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ul-li-block title-wrapper">
                                <div class="title-content">
                                    <h3><?php echo e($row['name'] ?? ''); ?></h3>
                                </div>
                                <ul>
                                    <li><?php echo e($row['item'] ?? ''); ?></li>
                                    <li class="text-warning"><b><i class="fas fa-dollar-sign"></i> <?php echo e(money_c($row['price']) ?? '0.00'); ?></b></li>
                                </ul>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <div class="button">
                                <a href="#addcart-modal" data-id="<?php echo e($table->id); ?>"
                                   data-searchtype="<?php echo e($searchType ?? ''); ?>"
                                   data-servicetype="<?php echo e($serviceType ?? ''); ?>"
                                   data-bookingdate="<?php echo e($bookingDate ?? ''); ?>"
                                   data-timeslotid="<?php echo e($timeSlotID ?? ''); ?>"
                                   data-partytype="<?php echo e($partyType ?? ''); ?>"
                                   data-guestnumber="<?php echo e($guestNumber ?? ''); ?>"
                                   data-cardnumber="<?php echo e($cardNumber ?? ''); ?>"
                                   class="custom-btn myy-btn lightBoxCart"><i class="fas fa-shopping-cart"></i> add to my cart</a>
                            </div>

                            <div class="location-info-list ul-li-block clearfix title-wrapper">
                                <div class="title-content">
                                    <h3>Facilities</h3>
                                </div>

                                <ul>
                                    <?php $__currentLoopData = $facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><i class="fas fa-arrow-circle-right"></i> <?php echo e($table->get_facility($row)['name'] ?? ''); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="location-info-list ul-li-block clearfix title-wrapper">
                                <div class="title-content">
                                    <h3>Rules</h3>
                                </div>
                                <ul>
                                    <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><i class="fas fa-arrow-circle-right"></i> <?php echo e($table->get_rules($row) ?? ''); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <div class="contact-links ul-li-block clearfix">
                                <div class="title-content">
                                    <h3><i class="fas fa-phone"></i> Contact</h3>
                                </div>

                                <ul>
                                    <?php if($contact['mobile'] != ''): ?>
                                    <li>
                                        <a href="#!" target="_blank" title="mobile">
												<span class="icon">
													<i class="fas fa-mobile-alt"></i>
												</span>
                                            <?php echo e($contact['mobile'] ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if($contact['phone'] != ''): ?>
                                    <li>
                                        <a href="#!" target="_blank" title="telephone">
												<span class="icon">
													<i class="fas fa-tty"></i>
												</span>
                                            <?php echo e($contact['phone'] ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if($contact['whatsApp'] != ''): ?>
                                    <li>
                                        <a href="#!" target="_blank" title="whatsApp">
												<span class="icon">
													<i class="fas fa-phone-volume"></i>
												</span>
                                            <?php echo e($contact['whatsApp'] ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if($contact['viber'] != ''): ?>
                                    <li>
                                        <a href="#!" target="_blank" title="viber">
												<span class="icon">
													<i class="fas fa-phone-volume"></i>
												</span>
                                            <?php echo e($contact['viber'] ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>

                                </ul>

                                <ul>
                                    <?php if($table->email != ''): ?>
                                    <li>
                                        <a href="#!" target="_blank" title="email">
												<span class="icon">
													<i class="fas fa-at"></i>
												</span>
                                            <?php echo e($table->email ?? ''); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if($table->website != ''): ?>
                                        <?php
                                            $result = parse_url($table->website)
                                        ?>
                                    <li>
                                        <a href="<?php echo e($table->website ?? '#!'); ?>" target="_blank"  title="website">
												<span class="icon">
													<i class="fas fa-globe"></i>
												</span>
                                            <?php echo e($result['host']); ?>

                                        </a>
                                    </li>
                                    <?php endif; ?>

                                </ul>

                                <div class="title-content">
                                    <h3><i class="fas fa-share-alt"></i> Social Link</h3>
                                </div>
                                <ul>
                                    <?php $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e($row['link'] ?? '#!'); ?>" target="_blank">
												<span class="icon">
													<i class="fas fa-link"></i>
												</span>
                                                <?php echo e($row['name'] ?? 'Unnamed'); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </div>
                        <!-- location-wrapper - end -->

                        <!-- faq-wrapper - start -->
                        <div class="faq-wrapper mb-30">

                            <!-- section-title - start -->
                            <div class="section-title mb-30">
                                <h2 class="big-title">Service <strong>FAQ</strong></h2>
                            </div>
                            <!-- section-title - end -->

                            <div id="faq-accordion" class="faq-accordion">

                                <?php $__currentLoopData = $faq_json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="card">
                                    <div class="card-header" id="heading<?php echo e($k); ?>">
                                        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($k); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($k); ?>">
                                            <?php echo e($row['question'] ?? ''); ?>

                                        </button>
                                    </div>

                                    <div id="collapse<?php echo e($k); ?>" class="collapse" aria-labelledby="heading<?php echo e($k); ?>" data-parent="#faq-accordion">
                                        <div class="card-body">
                                            <?php echo e($row['answer'] ?? ''); ?>

                                        </div>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>
                        <!-- faq-wrapper - end -->


                    </div>
                </div>
                <!-- sidebar-section - end -->

            </div>
        </div>
    </section>
    <!-- event-details-section - end
    ================================================== -->
    <?php echo $__env->make('shared.frontend.add-cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('public/css/jquery-gmaps-latlon-picker.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script2'); ?>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyCJ7FU3y6klDKrt1w1tnmWf2rEdkRydW3A&sensor=false"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery-gmaps-latlon-picker.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">

        $(function () {
            $('.lightBoxCart').click(function () {
                var id = $(this).data('id');
                var searchType = $(this).data('searchtype');
                var serviceType = $(this).data('servicetype');
                var bookingDate = $(this).data('bookingdate');
                var timeSlotID = $(this).data('timeslotid');
                var partyType = $(this).data('partytype');
                var guestNumber = $(this).data('guestnumber');
                var cardNumber = $(this).data('cardnumber');

                $.get( "<?php echo e(route('front.service-show-box')); ?>", {id : id, searchType : searchType, serviceType : serviceType, bookingDate : bookingDate, timeSlotID : timeSlotID, partyType : partyType, guestNumber : guestNumber, cardNumber : cardNumber}, function( data ) {
                    $('#show_form_box').html(data);
                });

            });
        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\frontend\single-service.blade.php ENDPATH**/ ?>