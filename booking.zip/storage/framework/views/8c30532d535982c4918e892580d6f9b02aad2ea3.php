<?php $__env->startSection('title'); ?>
    Search Result
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- breadcrumb-section - start
		================================================== -->
    <section id="breadcrumb-section" class="breadcrumb-section clearfix">
        <div class="jarallax" style="background-image: url(<?php echo e(asset('public/frontend/assets/images/breadcrumb/0.breadcrumb-bg.jpg')); ?>);">
            <div class="overlay-black">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-md-12 col-sm-12">

                            <!-- breadcrumb-title - start -->
                            <div class="breadcrumb-title text-center mb-50">
                                <span class="sub-title">Search Result</span>
                                <h2 class="big-title">Search <strong><?php echo e($searchType); ?></strong></h2>
                            </div>
                            <!-- breadcrumb-title - end -->

                            <!-- breadcrumb-list - start -->
                            <div class="breadcrumb-list">
                                <ul>
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>" class="breadcrumb-link">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($searchType); ?> listing</li>
                                </ul>
                            </div>
                            <!-- breadcrumb-list - end -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-section - end
    ================================================== -->




    <!-- event-search-section - start
    ================================================== -->
    <section id="event-search-section" class="event-search-section clearfix" style="background-image: url(<?php echo e(asset('public/frontend/assets/images/special-offer-bg.png')); ?>);">
        <div class="container">
            <div class="row">

                <!-- section-title - start -->
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="section-title">
                        <small class="sub-title">Find best Venue on Harmoni</small>
                        <h2 class="big-title">Venue <strong>Search</strong></h2>
                    </div>
                </div>
                <!-- section-title - end -->

            </div>
        </div>
    </section>
    <!-- event-search-section - end
    ================================================== -->

    <section class="event-search-tab">
        <?php echo $__env->make('shared.frontend.event-tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </section>

    <!-- event-section - start
    ================================================== -->
    <section id="event-section" class="event-section bg-gray-light sec-ptb-100 clearfix">
        <div class="container">
            <div class="row justify-content-center">

                <!-- - start -->
                <div class="col-lg-12 col-md-12 col-sm-12">

                    <div class="search-result-form">
                        <form action="#!">
                            <ul>

                                <li>
                                    <span class="result-text"><?php echo e($table->count()); ?> Search results from <?php echo e($total_event); ?> services</span>
                                </li>
                            </ul>
                        </form>
                    </div>

                    <div class="tab-content">
                        <div id="list-style" class="tab-pane fade in active show">

                            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php

                                    $photos = json_decode($row->photos, true);

                                    $facility_json = json_decode($row->facility, true);

                                    $additional = json_decode($row->additional, true);

                                    $pricings = json_decode($row->pricing, true);

                                    $prices = [];
                                    foreach ($pricings as $pricing){
                                        $prices[] = $pricing['price'];
                                    }
                                    $pricingx = Arr::sort($prices);

                                ?>

                            <!-- event-item - start -->
                            <div class="event-list-item clearfix">

                                <!-- event-image - start -->
                                <div class="event-image">
                                    <img src="<?php echo e(asset('public/gallery/'.$photos[0]['photo'])); ?>" alt="<?php echo e($photos[0]['name'] ?? 'Image Not Found'); ?>">
                                </div>
                                <!-- event-image - end -->

                                <!-- event-content - start -->
                                <div class="event-content">
                                    <div class="event-title mb-15">
                                        <h3 class="title">
                                            <a href="<?php echo e(route('front.single', ['id' => $row->id])); ?>?<?php echo e(build_http_query(request()->query())); ?>"><?php echo e($row->name); ?></a>
                                        </h3>

                                    </div>
                                    <div class="event-info-list ul-li clearfix">
                                        <ul>

                                            <?php
                                                $comment = $row->review()->count();
                                            ?>

                                            <li>
                                                <span class="icon">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                </span>
                                                <div class="info-content">
                                                    <h3>Near <?php echo e($row->landmark); ?>, <?php echo e($row->address); ?></h3>
                                                </div>
                                            </li>
                                            <li>
                                                <span class="icon">
                                                    <i class="fas fa-chart-line"></i>
                                                </span>
                                                <div class="info-content">
                                                    <h3>Rating: <?php echo e($row->rating); ?>/5 (<?php echo e($comment); ?>)</h3>
                                                </div>
                                            </li>
                                            <?php if($searchType == 'Venue' || $searchType == 'Food & Catering' || $searchType == 'Event Planer' ): ?>
                                            <li>
                                                <span class="icon">
                                                    <i class="fas fa-users"></i>
                                                </span>
                                                <div class="info-content">
                                                    <h3><?php echo e($row->minGuest); ?> - <?php echo e($row->maxGuest); ?></h3>
                                                </div>

                                            </li>
                                            <?php endif; ?>
                                            <li>
                                                <span class="icon">
                                                    <i class="fas fa-dollar-sign"></i>
                                                </span>
                                                <div class="info-content">
                                                    <p><?php echo e(money_c($pricingx[0]) ?? 0.00); ?></p>
                                                </div>
                                            </li>
                                        </ul>
                                        <p>
                                            <?php echo e($additional['description'] ?? ''); ?>

                                        </p>
                                        <?php if(count($facility_json) > 0): ?>
                                        <div class="event-icon">

                                            <ul>
                                                <?php $__currentLoopData = $facility_json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $facilitys = $row->get_facility($rows);

                                                    ?>
                                                    <li><img src="<?php echo e(asset('public/facility/'.$facilitys['icon'])); ?>" style="width: 48px;" alt=""><span><?php echo e($facilitys['name'] ?? ''); ?></span> </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                        <ul>
                                            <li>
                                                <a href="#addcart-modal" data-id="<?php echo e($row->id); ?>"
                                                   data-searchtype="<?php echo e($searchType ?? ''); ?>"
                                                   data-servicetype="<?php echo e($serviceType ?? ''); ?>"
                                                   data-bookingdate="<?php echo e($bookingDate ?? ''); ?>"
                                                   data-timeslotid="<?php echo e($timeSlotID ?? ''); ?>"
                                                   data-partytype="<?php echo e($partyType ?? ''); ?>"
                                                   data-guestnumber="<?php echo e($guestNumber ?? ''); ?>"
                                                   data-cardnumber="<?php echo e($cardNumber ?? ''); ?>"
                                                   class="tickets-details-btn lightBoxCart">
                                                    <i class="fas fa-shopping-cart"></i> add to my cart
                                                </a>

                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- event-content - end -->

                            </div>
                            <!-- event-item - end -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Pagination -->
                                <?php echo $table->appends(request()->query())->render(); ?>

                            <!-- /Pagination -->
                        </div>

                    </div>

                </div>
                <!-- - end -->

            </div>
        </div>
    </section>
    <!-- event-section - end
    ================================================== -->
    <?php echo $__env->make('shared.frontend.add-cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/gijgo.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('public/frontend/assets/js/gijgo.min.js')); ?>"></script>

    <script type="text/javascript">
        
        
        $(function () {
            $('.lightBoxCart').click(function () {
                var id = $(this).data('id');
                var searchType = $(this).data('searchtype');
                var serviceType = $(this).data('servicetype');
                var bookingDate = $(this).data('bookingdate');
                var timeSlotID = $(this).data('timeslotid');
                var partyType = $(this).data('partytype');
                var guestNumber = $(this).data('guestnumber');
                var cardNumber = $(this).data('cardnumber');
                $.get( "<?php echo e(route('front.service-show-box')); ?>", {id : id, searchType : searchType, serviceType : serviceType, bookingDate : bookingDate, timeSlotID : timeSlotID, partyType : partyType, guestNumber : guestNumber, cardNumber : cardNumber}, function( data ) {
                    $('#show_form_box').html(data);
                });

            });
        });
        
        
        

        $(function () {
            $('#datepic1').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic2').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic3').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic4').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic5').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic6').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });

            $('#datepic7').datepicker({
                format: 'dd/mm/yyyy',
                minDate: new Date(),
                icons: { rightIcon: null }
            });
        });

        
        $(function () {

            switch ("<?php echo e($searchType); ?>") {
                case "Food &amp; Catering":
                    $('#bBook').trigger('click');
                    $('#foodctaering [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#foodctaering [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#foodctaering [name=partyType]').val(<?php echo e($partyType); ?>);
                    $('#foodctaering [name=guestNumber]').val(<?php echo e($guestNumber); ?>);
                    break;
                case "Photographer":
                    $('#cBook').trigger('click');
                    $('#photographer [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#photographer [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#photographer [name=partyType]').val(<?php echo e($partyType); ?>);
                    break;
                case "Makeup Artist":
                    $('#dBook').trigger('click');
                    $('#makeupartist [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#makeupartist [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#makeupartist [name=partyType]').val(<?php echo e($partyType); ?>);
                    break;
                case "Henna Artist":
                    $('#eBook').trigger('click');
                    $('#hennaartist [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#hennaartist [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#hennaartist [name=partyType]').val(<?php echo e($partyType); ?>);
                    break;
                case "Event Planer":
                    $('#fBook').trigger('click');
                    $('#eventplanner [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#eventplanner [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#eventplanner [name=partyType]').val(<?php echo e($partyType); ?>);
                    $('#eventplanner [name=guestNumber]').val(<?php echo e($guestNumber); ?>);
                    break;
                case "Invitation Card":
                    $('#gBook').trigger('click');
                    $('#invitationcard [name=partyType]').val(<?php echo e($partyType); ?>);
                    $('#invitationcard [name=cardNumber]').val(<?php echo e($cardNumber); ?>);
                    break;
                case "Venue":
                    $('#aBook').trigger('click');
                    $('#venuebooking [name=bookingDate]').val("<?php echo e($bookingDate); ?>");
                    $('#venuebooking [name=timeSlot]').val(<?php echo e($timeSlotID); ?>);
                    $('#venuebooking [name=partyType]').val(<?php echo e($partyType); ?>);
                    $('#venuebooking [name=guestNumber]').val(<?php echo e($guestNumber); ?>);
            }
        });


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\frontend\search.blade.php ENDPATH**/ ?>