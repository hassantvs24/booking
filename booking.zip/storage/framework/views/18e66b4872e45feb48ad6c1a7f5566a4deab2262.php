<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/core.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('public/assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->
    <link href="<?php echo e(asset('public/custom.css')); ?>" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>



<!-- Page container -->
<div class="page-container">

    <!-- Page content -->
    <div class="page-content">

        <!-- Main content -->
        <div class="content-wrapper">

            <!-- Content area -->
            <div class="content">
                <div class="container">

                    <div class="row mb-10">
                        <?php echo $__env->yieldContent('back-url'); ?>
                    </div>

                <?php echo $__env->yieldContent('content'); ?>

                <!-- Basic modal -->
                <?php echo $__env->yieldContent('box'); ?>
                <!-- /basic modal -->
                    <!-- Footer -->
                <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /footer -->
                </div>
            </div>
            <!-- /content area -->

        </div>
        <!-- /main content -->

    </div>
    <!-- /page content -->

</div>
<!-- /page container -->
<!-- Core JS files -->
<?php echo $__env->yieldContent('script_up'); ?>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/loaders/pace.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/ui/moment/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/core/libraries/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/core/libraries/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
<!-- /core JS files -->

<script type="text/javascript" src="<?php echo e(asset('public/custom.js')); ?>"></script>

<script type="text/javascript">

</script>

<?php echo $__env->yieldContent('script'); ?>

</body>
</html><?php /**PATH C:\wamp64\www\booking\resources\views\layouts\basic.blade.php ENDPATH**/ ?>