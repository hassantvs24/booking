<?php $__env->startSection('title'); ?>
    Demo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">



    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\frontend\demo.blade.php ENDPATH**/ ?>