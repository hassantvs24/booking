<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.time_slot_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <p><button type="button" class="btn btn-primary btn-labeled <?php echo e(Auth::user()->access_view('time-slot-save')); ?>" data-toggle="modal" data-target="#myModal"><b><i class="icon-file-plus"></i></b> <?php echo app('translator')->get('site.content.time_slot_add'); ?></button></p>
        </div>
        <div class="col-md-6"></div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.time_slot_page'); ?></h6>
                </div>

                <div class="panel-body">
                    <table class="table table-bordered table-condensed table-hover datatable">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Time Slot Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th class="text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e(date('h:i A',strtotime($row->fromTime))); ?></td>
                                <td><?php echo e(date('h:i A',strtotime($row->toTime))); ?></td>
                                <td class="text-right white_sp">
                                    <button class="btn btn-xs btn-success no-padding mr-5 ediBtn <?php echo e(Auth::user()->access_view('time-slot-edit')); ?>"
                                            data-url="<?php echo e(route('time-slot-edit', ['id' => $row->id])); ?>"
                                            data-name="<?php echo e($row->name); ?>"
                                            data-from="<?php echo e($row->fromTime); ?>"
                                            data-to="<?php echo e($row->toTime); ?>"
                                            data-toggle="modal" data-target="#ediModal" title="<?php echo e(__('site.common.edi_title')); ?>"><i class="icon-pencil5"></i></button>
                                    <a class="btn btn-xs btn-danger no-padding <?php echo e(Auth::user()->access_view('time-slot-del')); ?>" href="<?php echo e(route('time-slot-del', ['id' => $row->id])); ?>" onclick='return confirm("<?php echo e(__('site.common.delete')); ?>")' title="<?php echo e(__('site.common.del_title')); ?>"><i class="icon-bin"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script type="text/javascript">
        $(function () {

            $('.ediBtn').click(function () {
                var url = $(this).data('url');
                var name = $(this).data('name');
                var fromTime = $(this).data('from');
                var toTime = $(this).data('to');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=fromTime]').val(fromTime);
                $('#ediModal [name=toTime]').val(toTime);

            });

        });


        $(function () {

            $('.datatable').DataTable({
                order: [[ 0, "desc" ]],
                columnDefs: [
                    { orderable: false, "targets": [4] }//For Column Order
                ]
            });
        });



    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('settings.box.time-slot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views/settings/time-slot.blade.php ENDPATH**/ ?>