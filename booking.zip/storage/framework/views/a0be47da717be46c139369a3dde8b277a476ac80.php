<?php $__env->startSection('title'); ?>
    Access denied
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- error-section - start
		================================================== -->
    <section id="error-section" class="error-section sec-ptb-100 bg-gray-light clearfix">
        <div class="container">
            <div class="row justify-content-center">

                <!-- error-content - start -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="icon">
                        <i class="far fa-frown"></i>
                    </div>
                </div>
                <!-- error-content - end -->

                <!-- error-content - start -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="error-content">
                        <h2>401</h2>
                        <h3>error - access denied</h3>
                        <p class="mb-30">something was wrong. Please contact with website admin.</p>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('front.home')); ?>" class="breadcrumb-link">Home</a></li>
                    </div>
                </div>
                <!-- error-content - end -->

            </div>
        </div>
    </section>
    <!-- error-section - end
    ================================================== -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script type="text/javascript">



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views/frontend/access.blade.php ENDPATH**/ ?>