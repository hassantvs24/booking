<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.location_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <p><button type="button" class="btn btn-primary btn-labeled" data-toggle="modal" data-target="#myModal"><b><i class="icon-file-plus"></i></b> <?php echo app('translator')->get('site.content.location_add'); ?></button></p>
        </div>
        <div class="col-md-6"></div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.location_page'); ?></h6>
                </div>

                <div class="panel-body">

                    <table class="table table-bordered table-condensed table-hover datatable">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Lat</th>
                            <th>Lon</th>
                            <th class="text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e($row->address); ?></td>
                                <td><?php echo e($row->lat); ?></td>
                                <td><?php echo e($row->lon); ?></td>
                                <td class="text-right white_sp">
                                    <button class="btn btn-xs btn-success no-padding mr-5 ediBtn"
                                            data-url="<?php echo e(route('location-edit', ['id' => $row->id])); ?>"
                                            data-name="<?php echo e($row->name); ?>"
                                            data-address="<?php echo e($row->address); ?>"
                                            data-lat="<?php echo e($row->lat); ?>"
                                            data-lon="<?php echo e($row->lon); ?>"
                                            data-toggle="modal" data-target="#ediModal" title="<?php echo e(__('site.common.edi_title')); ?>"><i class="icon-pencil5"></i></button>
                                    <a class="btn btn-xs btn-danger no-padding" href="<?php echo e(route('location-del', ['id' => $row->id])); ?>" onclick='return confirm("<?php echo e(__('site.common.delete')); ?>")' title="<?php echo e(__('site.common.del_title')); ?>"><i class="icon-bin"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('public/css/jquery-gmaps-latlon-picker.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyCJ7FU3y6klDKrt1w1tnmWf2rEdkRydW3A&sensor=false"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/js/jquery-gmaps-latlon-picker.js')); ?>"></script>

    <script type="text/javascript">
        $(function () {

            $('.ediBtn').click(function () {
                var url = $(this).data('url');
                var name = $(this).data('name');
                var address = $(this).data('address');
                var lat = $(this).data('lat');
                var lon = $(this).data('lon');

                $('#ediModal form').attr('action', url);
                $('#ediModal [name=name]').val(name);
                $('#ediModal [name=address]').val(address);
                $('#ediModal [name=lat]').val(lat);
                $('#ediModal [name=lon]').val(lon);

            });

        });


        $(function () {

            $('.datatable').DataTable({
                order: [[ 0, "desc" ]],
                columnDefs: [
                    { orderable: false, "targets": [5] }//For Column Order
                ]
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('settings.box.location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\settings\location.blade.php ENDPATH**/ ?>