<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.old_booking_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.old_booking_page'); ?></h6>
                </div>

                <div class="panel-body" style="overflow-x: auto;">
                    <table class="table table-bordered table-condensed table-hover datatable">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th title="Service Date">S.Date</th>
                            <th>Company</th>
                            <th>Service</th>
                            <th class="text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e(pub_date($row->created_at)); ?></td>
                                <td><?php echo e($row->status); ?></td>
                                <td><?php echo e($row->customer['name']); ?></td>
                                <td><?php echo e($row->customer['contact']); ?></td>
                                <?php
                                    $items = $row->item()->get();
                                    $serviceDate = '';
                                    $company = '';
                                    $service = '';
                                    $price = '';

                                    $full_amount = 0;
                                foreach($items as $rows){
                                        $serviceDate .= '<p class="no-margin border-bottom border-bottom-info-300">'.pub_date($rows->serviceDate).'</p>';
                                        $company .= '<p class="no-margin white_sp border-bottom border-bottom-info-300">'.$rows->service['name'].'</p>';
                                        $service .= '<p class="no-margin white_sp border-bottom border-bottom-info-300">'.$rows->service['serviceType'].'</p>';

                                        $full_amount += ($rows->pricing * $rows->qty);
                                }
                                ?>
                                <td><?php echo $serviceDate; ?></td>
                                <td><?php echo $company; ?></td>
                                <td><?php echo $service; ?></td>
                                <td class="text-right white_sp">
                                    <?php if($row->status == 'Complete'): ?>
                                        <button class="btn btn-xs btn-success no-padding show_book_info <?php echo e(Auth::user()->access_view('booking-show')); ?>" data-url="<?php echo e(route('booking-show', ['id' => $row->id])); ?>" data-toggle="modal" data-target="#bookingModal" title="<?php echo e(__('site.common.view_title')); ?>"><i class="icon-eye"></i></button>
                                        <?php else: ?>
                                        <button class="btn btn-xs btn-warning no-padding show_book_info <?php echo e(Auth::user()->access_view('booking-show')); ?>" data-url="<?php echo e(route('booking-show', ['id' => $row->id])); ?>" data-toggle="modal" data-target="#bookingModal" title="<?php echo e(__('site.common.view_title')); ?>"><i class="icon-eye"></i></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script type="text/javascript">
        
        $(function () {
            $('.show_book_info').click(function () {
                var url = $(this).data('url');
                $('#show_book_info').html('Loading ...');
                $.get(url, function( result ) {
                    $('#show_book_info').html(result);
                });
            });

        });


        $(function () {

            $('.datatable').DataTable({
                order: [[ 0, "desc" ]],
                columnDefs: [
                    { orderable: false, "targets": [8] }//For Column Order
                ]
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('booking.box.booking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views/booking/old_booking.blade.php ENDPATH**/ ?>