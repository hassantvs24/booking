
<div id="addcart-modal" class="reglog-modal-wrapper mfp-hide clearfix" style="background-image: url(<?php echo e(asset('public/frontend/assets/images/login-modal-bg.jpg')); ?>);">
    <div class="overlay-black clearfix">
        <!-- rightside-content - start -->
        <div class="rightside-content text-center">

            <div class="mb-30">
                <h2 class="form-title title-large white-color">Order <strong>Now</strong></h2>
            </div>

            <div class="login-form text-center mb-50" id="show_form_box">

            </div>

        </div>
        <!-- rightside-content - end -->

        <a class="popup-modal-dismiss" href="#!">
            <i class="fas fa-times"></i>
        </a>

    </div>
</div><?php /**PATH C:\wamp64\www\booking\resources\views\shared\frontend\add-cart.blade.php ENDPATH**/ ?>