<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.booking_task_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.booking_task_page'); ?></h6>
                </div>

                <div class="panel-body" style="overflow-x: auto;">
                    <table class="table table-bordered table-condensed table-hover datatable">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th title="Booking ID">BookingID</th>
                            <th>Date</th>
                            <th>Time Slot</th>
                            <th>Service</th>
                            <th>Company</th>
                            <th>Price x Qty</th>
                            <th>Amount</th>
                            <th class="text-right">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><button class="btn-link no-padding show_book_info" data-url="<?php echo e(route('booking-show', ['id' => $row->bookingID])); ?>" data-toggle="modal" data-target="#bookingModal" title="<?php echo e(__('site.common.view_title')); ?>"><u><?php echo e($row->bookingID); ?></u></button></td>
                                <td><?php echo e(pub_date($row->serviceDate)); ?></td>
                                <td><?php echo e($row->time_slot['name'] ?? ''); ?> (<?php echo e(date('ha', strtotime($row->time_slot['fromTime'])) ?? ''); ?>-<?php echo e(date('ha', strtotime($row->time_slot['toTime'])) ?? ''); ?>)</td>
                                <td><?php echo e($row->service['serviceType'] ?? ''); ?></td>
                                <td><?php echo e($row->service['name'] ?? ''); ?></td>
                                <td><?php echo e(money_c($row->pricing)); ?> x <?php echo e($row->qty); ?></td>
                                <td><?php echo e(money_c($row->pricing * $row->qty)); ?></td>
                                <td class="text-right">
                                    <?php if($row->isComplete == null): ?>
                                        <a class="btn btn-xs btn-success no-padding" href="<?php echo e(route('task-complete', ['id' => $row->id])); ?>" onclick='return confirm("Are you sure this task is complete?")' title="<?php echo e(__('site.content.booking_task_complete')); ?>"><i class="icon-checkmark2"></i></a>
                                        <?php else: ?>
                                        <a class="btn btn-xs btn-warning no-padding" href="<?php echo e(route('task-complete', ['id' => $row->id])); ?>" onclick='return confirm("Are you sure this is incomplete task?")' title="<?php echo e(__('site.content.booking_task_reback')); ?>"><i class="icon-undo2"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script type="text/javascript">

        $(function () {
            $('.show_book_info').click(function () {
                $('#show_book_info').html('Loading ...');
                var url = $(this).data('url');
                $.get(url, function( result ) {
                    $('#show_book_info').html(result);
                });
            });

        });


        $(function () {

            $('.datatable').DataTable({
                order: [[ 0, "desc" ]],
                columnDefs: [
                    { orderable: false, "targets": [8] }//For Column Order
                ]
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('booking.box.booking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\booking\task.blade.php ENDPATH**/ ?>