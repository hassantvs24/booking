<div class="sidebar sidebar-main sidebar-fixed">
    <div class="sidebar-content">
        <!-- Main navigation -->
        <div class="sidebar-category sidebar-category-visible">
            <div class="category-content no-padding">
                <ul class="navigation navigation-main navigation-accordion">

                    <!-- Main -->
                    <li class="<?php echo e(Request::routeIs('dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="icon-home4"></i> <span><?php echo app('translator')->get('site.aside.dashboard'); ?></span></a></li>

                    <li class="<?php echo e((Request::is('booking/*','booking') ? 'active' : '')); ?>">
                        <a href="#"><i class="icon-bookmark"></i> <span> <?php echo app('translator')->get('site.aside.booking'); ?></span></a>
                        <ul>
                            <li class="<?php echo e(Request::routeIs('new-booking') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('new-booking')); ?>"><a href="<?php echo e(route('new-booking')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.new_booking'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('booking-task') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('booking-task')); ?>"><a href="<?php echo e(route('booking-task')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.booking_task'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('old-booking') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('old-booking')); ?>"><a href="<?php echo e(route('old-booking')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.booking_archive'); ?></a></li>
                        </ul>
                    </li>

                    <li class="navigation-divider"></li>

                    <li class="<?php echo e(Request::routeIs('service') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('service')); ?>"><a href="<?php echo e(route('service')); ?>"><i class="icon-theater"></i> <span><?php echo app('translator')->get('site.aside.service_list'); ?></span></a></li>


                    <li class="navigation-divider"></li>

                    <li class="<?php echo e((Request::is('settings/*','settings') ? 'active' : '')); ?>">
                        <a href="#"><i class="icon-cog2"></i> <span> <?php echo app('translator')->get('site.aside.settings'); ?></span></a>
                        <ul>
                            <li class="<?php echo e(Request::routeIs('party') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('party')); ?>"><a href="<?php echo e(route('party')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.party'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('location') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('location')); ?>"><a href="<?php echo e(route('location')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.location'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('facility') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('facility')); ?>"><a href="<?php echo e(route('facility')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.facility'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('time-slot') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('time-slot')); ?>"><a href="<?php echo e(route('time-slot')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.time_slot'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('rules') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('rules')); ?>"><a href="<?php echo e(route('rules')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.rules'); ?></a></li>
                        </ul>
                    </li>

                    <li class="navigation-divider"></li>

                    <li class="<?php echo e((Request::is('users/*','users') ? 'active' : '')); ?>">
                        <a href="#"><i class="icon-user"></i> <span> <?php echo app('translator')->get('site.aside.user'); ?></span></a>
                        <ul>
                            <li class="<?php echo e(Request::routeIs('users-list') ? 'active' : ''); ?> <?php echo e(Auth::user()->access_view('users-list')); ?>"><a href="<?php echo e(route('users-list')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.all_user'); ?></a></li>
                            <li class="<?php echo e(Request::routeIs('user-role') ? 'active' : ''); ?>" <?php echo e(Auth::user()->access_view('user-role')); ?>><a href="<?php echo e(route('user-role')); ?>"><i class="icon-diamond3"></i> <?php echo app('translator')->get('site.aside.user_role'); ?></a></li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
        <!-- /main navigation -->
    </div>
</div>
<?php /**PATH C:\wamp64\www\booking\resources\views/shared/aside.blade.php ENDPATH**/ ?>