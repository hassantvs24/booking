<header id="header-section" class="header-section default-header-section auto-hide-header clearfix">
    <!-- header-top - start -->
    <div class="header-top">
        <div class="container">
            <div class="row">
                <!-- basic-contact - start -->
                <div class="col-lg-6">
                    <div class="basic-contact">
                        <ul>
                            <li>
                                <a href="#!">
                                    <i class="fas fa-envelope"></i>
                                    info@infinityflamesoft.com
                                </a>
                            </li>
                            <li>
                                <a href="#!">
                                    <i class="fas fa-phone"></i>
                                    01675-870047
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- basic-contact - end -->
                <!-- register-login-group - start -->
                <div class="col-lg-6">
                    <div class="register-login-group">
                        <ul>
                            <li>
                                <?php if(Auth::check()): ?>
                                    <a href="<?php echo e(route('front.user')); ?>" class="">
                                        <i class="fas fa-user"></i>
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('front.login-register')); ?>" class="">
                                        <i class="fas fa-bookmark"></i>
                                        Register
                                    </a>
                                <?php endif; ?>
                            </li>
                            <li>
                                <?php if(Auth::check()): ?>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <i class="fas fa-lock"></i>
                                    Logout
                                </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('front.login-register')); ?>" class="">
                                        <i class="fas fa-unlock"></i>
                                        Login
                                    </a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- register-login-group - end -->

            </div>
        </div>
    </div>
    <!-- header-top - end -->

    <!-- header-bottom - start -->
    <div class="header-bottom">
        <div class="container">
            <div class="row">

                <!-- site-logo-wrapper - start -->
                <div class="col-lg-3">
                    <div class="site-logo-wrapper">
                        <a href="<?php echo e(route('front.home')); ?>" class="logo">
                            <img src="<?php echo e(asset('public/frontend/assets/images/0.site-logo.png')); ?>" alt="logo_not_found">
                        </a>
                    </div>
                </div>
                <!-- site-logo-wrapper - end -->

                <!-- mainmenu-wrapper - start -->
                <div class="col-lg-9">
                    <div class="mainmenu-wrapper">
                        <div class="row">

                            <!-- menu-item-list - start -->
                            <div class="col-lg-10">
                                <div class="menu-item-list ul-li clearfix">
                                    <ul>
                                        <li class="menu-item-has-children <?php echo e(Request::routeIs('front.home') ? 'active' : ''); ?>">
                                            <a href="<?php echo e(route('front.home')); ?>">home</a>
                                        </li>
                                        <li class="menu-item-has-children <?php echo e(Request::routeIs('front.about') ? 'active' : ''); ?>">
                                            <a href="<?php echo e(route('front.about')); ?>">about</a>
                                        </li>
                                        <li class="menu-item-has-children <?php echo e(Request::routeIs('front.service') ? 'active' : ''); ?>">
                                            <a href="<?php echo e(route('front.service')); ?>">services</a>
                                        </li>
                                        <li class="menu-item-has-children <?php echo e(Request::routeIs('front.gallery') ? 'active' : ''); ?>">
                                            <a href="<?php echo e(route('front.gallery')); ?>">gallery</a>
                                        </li>
                                        <li class="menu-item-has-children <?php echo e(Request::routeIs('front.contact') ? 'active' : ''); ?>">
                                            <a href="<?php echo e(route('front.contact')); ?>">contact</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- menu-item-list - end -->

                            <!-- menu-item-list - start -->
                            <div class="col-lg-2">
                                <div class="user-search-btn-group ul-li clearfix">
                                    <ul>
                                        <li>
                                            <?php if($temp_cart->count() > 0): ?>
                                            <span class="badge badge-info" style="position: absolute; border-radius: 15px;"><?php echo e($temp_cart->count()); ?></span>
                                            <?php endif; ?>
                                            <button type="button" class="toggle-overlay search-btn">

                                                <i class="fas fa-shopping-cart"></i>
                                            </button>
                                            <!-- search-body - start -->
                                                <?php if($temp_cart->count() > 0): ?>
                                            <div class="search-body" style="width: auto;">
                                                <div class="search-form">
                                                    <table class="table table-bordered">
                                                        <?php
                                                            $total_temp_value = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $temp_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <tr>
                                                                <td><?php echo e($row->services['name']); ?></td>
                                                                <td><?php echo e($row->services['serviceType']); ?></td>
                                                                <td style="white-space: nowrap;"><i class="fas fa-dollar-sign"></i> <?php echo e(money_c($row->pricing * $row->qty)); ?></td>
                                                            </tr>
                                                            <?php
                                                                $total_temp_value += ($row->pricing * $row->qty);
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="text-warning">
                                                            <td><b>Total</b></td>
                                                            <td style="white-space: nowrap;"><i class="fas fa-dollar-sign"></i> <?php echo e(money_c($total_temp_value)); ?></td>
                                                            <td><a href="<?php echo e(route('front.checkout')); ?>" class="custom-btn"><i class="fas fa-shopping-cart"></i>checkout</a></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <!-- search-body - end -->
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- menu-item-list - end -->

                        </div>
                    </div>
                </div>
                <!-- mainmenu-wrapper - end -->

            </div>
        </div>
    </div>
    <!-- header-bottom - end -->

</header><?php /**PATH C:\wamp64\www\booking\resources\views/shared/frontend/header.blade.php ENDPATH**/ ?>