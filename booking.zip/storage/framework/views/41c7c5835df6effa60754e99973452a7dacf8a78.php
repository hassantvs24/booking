<form action="<?php echo e(route('front.add-cart')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="serviceID" value="<?php echo e($table->id); ?>">
    <div class="form-item">
        <input type="date" name="bookingDate" placeholder="dd/mm/yyyy" value="<?php echo e($bookingDate); ?>" required>
    </div>
    <div class="form-item">
        <select name="timeSlotID" required>
            <option selected="">Time Slot</option>
            <?php $__currentLoopData = $time_slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->id); ?>" <?php echo e($row->id == $timeSlotID ? 'selected':''); ?>><?php echo e($row->name); ?> (<?php echo e(date('h a', strtotime($row->fromTime))); ?> - <?php echo e(date('h a', strtotime($row->toTime))); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-item">
        <select name="partyType" required>
            <option selected="">Party type</option>
            <?php $__currentLoopData = $party_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->id); ?>" <?php echo e($row->id == $partyType ? 'selected':''); ?>><?php echo e($row->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php if($table->serviceType == 'Venue Booking' || $table->serviceType == 'Food & Catering' || $table->serviceType == 'Event Planer' ): ?>
    <div class="form-item">
        <input type="number" name="guestNumber" placeholder="Number of guest" min="<?php echo e($table->minGuest ?? 0); ?>" max="<?php echo e($table->maxGuest); ?>" value="<?php echo e($guestNumber); ?>" required>
    </div>
    <?php endif; ?>

    <?php
        $pricing = json_decode($table->pricing, true);
    ?>

    <div style="max-height: 185px; overflow-y: auto;">

    <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check" style="text-align: left;">
            <input type="radio" name="pricing" class="form-check-input" value="<?php echo e($row['price']); ?>, <?php echo e($i); ?>" id="exampleCheck<?php echo e($i); ?>" required>
            <label class="form-check-label" style="color: #0a001f;" for="exampleCheck<?php echo e($i); ?>"><?php echo e($row['name'] ?? ''); ?> | <?php echo e($row['item'] ?? ''); ?> | <i class="fas fa-dollar-sign"></i> <?php echo e(money_c($row['price']) ?? '0.00'); ?></label>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button type="submit" class="login-btn">Order now</button>
</form>
<?php /**PATH C:\wamp64\www\booking\resources\views/frontend/light-box/add-cart.blade.php ENDPATH**/ ?>