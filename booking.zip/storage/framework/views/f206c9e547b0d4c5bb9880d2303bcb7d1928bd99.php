<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.content.dashboard_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-flat border-top-success">
                <div class="panel-heading">
                    <h6 class="panel-title"><?php echo app('translator')->get('site.content.dashboard_page'); ?></h6>
                </div>

                <div class="panel-body">


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script type="text/javascript">




    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\booking\resources\views\dashboard\dashboard.blade.php ENDPATH**/ ?>