<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title'); ?> | Booking</title>
    <link href="<?php echo e(asset('public/frontend/assets/images/favicon.png')); ?>" rel="shortcut icon">

    <!-- fraimwork - css include -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/bootstrap.min.css')); ?>">


    <!-- icon css include -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/flaticon.css')); ?>">



    <!-- carousel css include -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/owl.theme.default.min.css')); ?>">

    <!-- others css include -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/jquery.mCustomScrollbar.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/calendar.css')); ?>">


    <!-- custom css include -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/assets/css/style.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>

</head>
<body class="homepage3 default-header-p">
<!-- backtotop - start -->
<div id="thetop" class="thetop"></div>
<div class='backtotop'>
    <a href="#thetop" class='scroll'>
        <i class="fas fa-angle-double-up"></i>
    </a>
</div>
<!-- backtotop - end -->

<!-- preloader - start -->
<div id="preloader"></div>
<!-- preloader - end -->




<!-- header-section - start
================================================== -->
<?php echo $__env->make('shared.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header-section - end
================================================== -->


<!-- altranative-header - start
================================================== -->
<?php echo $__env->make('shared.frontend.header-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- altranative-header - end
================================================== -->


<?php echo $__env->yieldContent('content'); ?>


<!-- default-footer-section - start
================================================== -->

<?php echo $__env->make('shared.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- default-footer-section - end
================================================== -->

<!-- fraimwork - jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/bootstrap.min.js')); ?>"></script>

<!-- carousel jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/owl.carousel.min.js')); ?>"></script>

<!-- map jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/gmap3.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script2'); ?>
<!--<script src="http://maps.google.com/maps/api/js?key=AIzaSyC61_QVqt9LAhwFdlQmsNwi5aUJy9B2SyA"></script>-->

<!-- calendar jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/atc.min.js')); ?>"></script>

<!-- others jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/jarallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/frontend/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

<!-- gallery img loaded - jqury include -->
<script src="<?php echo e(asset('public/frontend/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>

<!-- multy count down - jqury include -->
<script src="<?php echo e(asset('public/frontend/assets/js/jquery.countdown.js')); ?>"></script>

<!-- custom jquery include -->
<script src="<?php echo e(asset('public/frontend/assets/js/custom.js')); ?>"></script>


<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\wamp64\www\booking\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>