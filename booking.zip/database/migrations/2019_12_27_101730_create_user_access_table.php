<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserAccessTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_access', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('userRuleID')->nullable()->unsigned()->index();
            $table->foreign('userRuleID')->references('id')->on('user_rules')->onDelete('cascade')->onUpdate('No Action');
            $table->string('name');
            $table->string('access', 50);
            $table->unique('userRuleID', 'access');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_access');
    }
}
