<?php

return [
    'aside' => [
        'dashboard' => 'ডেশবোর্ড',

        'settings' => 'সেটিংস',
        'location' => 'লোকেশন',
        'facility' => 'সুবিধা সমুহ',
        'time_slot' => 'সময় সেট',
        'rules' => 'শর্তগুলো'
    ],

];
