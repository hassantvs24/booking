@extends('layouts.frontend')

@section('title')
    Demo
@endsection

@section('content')



@endsection


@section('script')
    <script type="text/javascript">



    </script>
@endsection